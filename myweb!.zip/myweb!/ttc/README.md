## TicTacToe
A tic-tac-toe game with an intelligent bot made using HTML, CSS & JavaScript.

### Technical Stack
* HTML
* CSS
* JavaScript
